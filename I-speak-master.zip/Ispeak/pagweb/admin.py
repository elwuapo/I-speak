from django.contrib import admin
from .models import Diccionario, Publicacion

# Register your models here.

admin.site.register(Diccionario)
admin.site.register(Publicacion)
