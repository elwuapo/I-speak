from django.apps import AppConfig


class PagwebConfig(AppConfig):
    name = 'pagweb'
